# Orbit Android Project v1.0.2

এই ZIP-এ Android Studio/ GitHub Actions দিয়ে build করার Android WebView app source আছে।

## v1.0.2 changes
- Responsive layout hardening for small/large screens, landscape and safe areas; allow user zoom for accessibility.
- Android download bridge saves files in the public `Downloads/Orbit` folder on Android 10+.
- Print/PDF uses Android Print Framework so the user can select “Save as PDF”.
- Email report opens the chosen email app with an attendance CSV attachment; user must review and tap Send. This app does not silently send email.
- App version updated to 1.0.2.

## Important limitations / testing
- This source has not been compiled with Android SDK in this environment. Use GitHub Actions to build and verify the APK before installing.
- Background geofence reliability depends on Android permissions, Google Play Services, location settings and device battery restrictions. Force Stop can prevent events.
- Email attachment, PNG/XLSX downloads and PDF print dialog should be tested on actual Android devices before company-wide rollout.
- Existing app local data is stored on each device. Do not uninstall the old app before making a backup; package id/signing compatibility determines whether an update preserves installed data.
