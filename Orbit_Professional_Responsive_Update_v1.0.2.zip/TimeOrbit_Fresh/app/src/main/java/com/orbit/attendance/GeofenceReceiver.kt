package com.orbit.attendance

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent
import org.json.JSONArray
import org.json.JSONObject

class GeofenceReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val event = GeofencingEvent.fromIntent(intent) ?: return
        if (event.hasError()) return
        val kind = when (event.geofenceTransition) {
            Geofence.GEOFENCE_TRANSITION_ENTER -> "in"
            Geofence.GEOFENCE_TRANSITION_EXIT -> "out"
            else -> return
        }
        val prefs = context.getSharedPreferences("orbit_native", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        // Android may report the same transition more than once; ignore near-duplicates.
        val lastKind = prefs.getString("last_geo_kind", "") ?: ""
        val lastTime = prefs.getLong("last_geo_time", 0L)
        if (lastKind == kind && now - lastTime < 3 * 60 * 1000L) return

        val arr = try { JSONArray(prefs.getString("pending_punches", "[]")) } catch (_: Exception) { JSONArray() }
        arr.put(JSONObject().put("kind", kind).put("timestamp", now))
        // Keep the queue bounded while preserving recent offline transitions.
        while (arr.length() > 100) arr.remove(0)
        prefs.edit().putString("pending_punches", arr.toString())
            .putString("last_geo_kind", kind).putLong("last_geo_time", now).apply()

        // Native notification confirms the event even if Orbit's screen is closed.
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel("orbit_geofence", "Automatic attendance", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val open = PendingIntent.getActivity(context, 711, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val label = if (kind == "in") "IN" else "OUT"
        manager.notify(710, NotificationCompat.Builder(context, "orbit_geofence")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Orbit automatic $label")
            .setContentText(if (kind == "in") "Office entry detected. Time saved for syncing." else "Office exit detected. Time saved for syncing.")
            .setAutoCancel(true).setContentIntent(open).build())
    }
}
