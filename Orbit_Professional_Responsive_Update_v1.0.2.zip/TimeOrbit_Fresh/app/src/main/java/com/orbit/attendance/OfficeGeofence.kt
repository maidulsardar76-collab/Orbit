package com.orbit.attendance

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices

/** Registers the office boundary without requiring the app UI to remain open. */
object OfficeGeofence {
    fun register(context: Context) {
        val app = context.applicationContext
        val prefs = app.getSharedPreferences("orbit_native", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("geo_enabled", false)) return
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            prefs.edit().putString("geo_error", "Fine location permission is missing").apply(); return
        }
        if (Build.VERSION.SDK_INT >= 29 && ContextCompat.checkSelfPermission(app, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            prefs.edit().putString("geo_error", "Allow all the time location permission is required").apply(); return
        }
        val lat = prefs.getFloat("office_lat", 0f).toDouble()
        val lon = prefs.getFloat("office_lon", 0f).toDouble()
        val radius = prefs.getFloat("office_radius", 100f).coerceIn(30f, 1000f)
        if (lat !in -90.0..90.0 || lon !in -180.0..180.0 || (lat == 0.0 && lon == 0.0)) return
        val fence = Geofence.Builder()
            .setRequestId("orbit_office")
            .setCircularRegion(lat, lon, radius)
            .setExpirationDuration(Geofence.NEVER_EXPIRE)
            .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER or Geofence.GEOFENCE_TRANSITION_EXIT)
            .setNotificationResponsiveness(10000)
            .build()
        val request = GeofencingRequest.Builder()
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            .addGeofence(fence)
            .build()
        val pending = PendingIntent.getBroadcast(
            app, 710, Intent(app, GeofenceReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
        LocationServices.getGeofencingClient(app).addGeofences(request, pending)
            .addOnSuccessListener { prefs.edit().remove("geo_error").putBoolean("geo_registered", true).apply() }
            .addOnFailureListener { prefs.edit().putBoolean("geo_registered", false).putString("geo_error", it.message ?: "Geofence registration failed").apply() }
    }
}
