package com.orbit.attendance

import android.Manifest
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.provider.MediaStore
import android.print.PrintManager
import android.content.ContentValues
import android.os.Environment
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.GeofenceStatusCodes
import java.io.File
import java.io.FileOutputStream
import java.util.Calendar
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("orbit_native", Context.MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestBasicPermissions()
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.loadWithOverviewMode = true
        web.settings.useWideViewPort = true
        web.settings.textZoom = 100
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(OrbitBridge(this), "EasyPunchNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }
    private fun requestBasicPermissions() {
        val required = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) required.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = required.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 410)
        else ensureBackgroundLocationPermission()
    }

    private fun ensureBackgroundLocationPermission() {
        if (Build.VERSION.SDK_INT < 29) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            if (prefs.getBoolean("geo_enabled", false)) OfficeGeofence.register(this)
            return
        }
        if (prefs.getBoolean("background_location_prompted", false)) return
        prefs.edit().putBoolean("background_location_prompted", true).apply()
        AlertDialog.Builder(this)
            .setTitle("Allow Orbit location in background")
            .setMessage("Automatic IN/OUT must work while Orbit is closed. On the next screen, open Permissions → Location and select ‘Allow all the time’. Also keep phone Location enabled.")
            .setCancelable(false)
            .setPositiveButton("Continue") { _, _ ->
                if (Build.VERSION.SDK_INT >= 30) {
                    try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
                    catch (_: Exception) { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }
                } else {
                    ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 411)
                }
            }
            .setNegativeButton("Later", null)
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 410 || requestCode == 411) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                ensureBackgroundLocationPermission()
                if (prefs.getBoolean("geo_enabled", false)) OfficeGeofence.register(this)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= 29 && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED && prefs.getBoolean("geo_enabled", false)) {
            OfficeGeofence.register(this)
        }
        if (::web.isInitialized) web.evaluateJavascript("try{syncNativeGeofenceEvents&&syncNativeGeofenceEvents()}catch(e){}", null)
    }
    inner class OrbitBridge(private val ctx: Context) {
        @JavascriptInterface fun scheduleDailyReminder(kind: String, time: String, enabled: Boolean): String = try {
            val key = "${kind}_time"; prefs.edit().putString(key, time).putBoolean("${kind}_enabled", enabled).apply()
            if (enabled) schedule(kind, time) else cancel(kind)
            "OK"
        } catch (e: Exception) { "ERROR:${e.message}" }
        @JavascriptInterface fun printPage(): String = try {
            val manager = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
            val adapter = web.createPrintDocumentAdapter("Orbit-Attendance-Report")
            manager.print("Orbit Attendance Report", adapter, android.print.PrintAttributes.Builder().setMediaSize(android.print.PrintAttributes.MediaSize.ISO_A4).setColorMode(android.print.PrintAttributes.COLOR_MODE_COLOR).build())
            "OK"
        } catch (e: Exception) { "ERROR:${e.message ?: "Print/PDF unavailable"}" }

        @JavascriptInterface fun openEmail(to: String, subject: String, body: String): String = try {
            val i = Intent(Intent.ACTION_SENDTO).apply { data = Uri.parse("mailto:"); putExtra(Intent.EXTRA_EMAIL, arrayOf(to)); putExtra(Intent.EXTRA_SUBJECT, subject); putExtra(Intent.EXTRA_TEXT, body); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            ctx.startActivity(Intent.createChooser(i, "Send Orbit attendance report").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "OK"
        } catch (e: Exception) { "ERROR:No email app available. ${e.message}" }
        @JavascriptInterface fun openEmailAttachment(to: String, subject: String, body: String, base64: String, fileName: String, mime: String): String = try {
            val dir = File(ctx.cacheDir, "email_reports").apply { mkdirs() }
            val safe = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val file = File(dir, safe)
            FileOutputStream(file).use { it.write(Base64.decode(base64, Base64.DEFAULT)) }
            val uri = androidx.core.content.FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = mime.ifBlank { "text/csv" }
                putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = android.content.ClipData.newUri(ctx.contentResolver, safe, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(Intent.createChooser(send, "Send Orbit attendance report").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "OK"
        } catch (e: Exception) { "ERROR:${e.message ?: "Could not attach report"}" }

        @JavascriptInterface fun registerOfficeGeofence(lat: Double, lon: Double, radius: Float): String {
          return try {
            prefs.edit().putFloat("office_lat", lat.toFloat()).putFloat("office_lon", lon.toFloat()).putFloat("office_radius", radius).putBoolean("geo_enabled", true).apply()
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return "ERROR:Location permission not granted"
            if (Build.VERSION.SDK_INT >= 29 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) return "ERROR:Allow all the time location permission is required for automatic IN/OUT while Orbit is closed"
            OfficeGeofence.register(ctx)
            "OK"
          } catch (e: Exception) { "ERROR:${e.message}" }
        }
        @JavascriptInterface fun consumePendingPunches(): String = prefs.getString("pending_punches", "[]") ?: "[]"
        @JavascriptInterface fun acknowledgePendingPunches() { prefs.edit().putString("pending_punches", "[]").apply() }
        @JavascriptInterface fun saveDownload(base64: String, name: String, mime: String): String = try {
            val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, safe)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime.ifBlank { "application/octet-stream" })
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Orbit")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val resolver = ctx.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return "ERROR:Could not create a file in Downloads"
                try {
                    resolver.openOutputStream(uri)?.use { it.write(bytes) } ?: throw IllegalStateException("Could not open output stream")
                    val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                    resolver.update(uri, done, null, null)
                } catch (e: Exception) { resolver.delete(uri, null, null); throw e }
            } else {
                val dir = File(ctx.getExternalFilesDir(null), "OrbitDownloads"); dir.mkdirs()
                FileOutputStream(File(dir, safe)).use { it.write(bytes) }
            }
            "OK"
        } catch (e: Exception) { "ERROR:${e.message ?: "Unknown file error"}" }
    }
    private fun schedule(kind: String, time: String) {
        val parts = time.split(":"); if (parts.size != 2) return
        val hour = parts[0].toIntOrNull() ?: return; val minute = parts[1].toIntOrNull() ?: return
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("kind", kind)
        val pi = PendingIntent.getBroadcast(this, if (kind == "in") 801 else 802, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi) else am.set(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
    }
    private fun cancel(kind: String) { val pi = PendingIntent.getBroadcast(this, if (kind == "in") 801 else 802, Intent(this, ReminderReceiver::class.java).putExtra("kind", kind), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE); if (pi != null) (getSystemService(ALARM_SERVICE) as AlarmManager).cancel(pi) }
    override fun onBackPressed() { if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
}
