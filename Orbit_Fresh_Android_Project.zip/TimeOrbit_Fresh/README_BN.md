# Orbit — Fresh Android project (বাংলা গাইড)

এটি TimeOrbit-v15.2 APK-এর ভেতর থেকে পাওয়া HTML/JavaScript UI-কে নতুন Android WebView প্রজেক্টে রাখা একটি **প্রাথমিক fresh build project**। নতুন package ID: `com.orbit.attendance.fresh`; app name: `Orbit`। ফলে আগের Easy Punch/TimeOrbit অ্যাপের সঙ্গে আলাদা করে ইনস্টল হওয়ার কথা। পুরোনো অ্যাপ আনইনস্টল করবেন না।

## এই ZIP-এ কী আছে
- `app/src/main/assets/` — উদ্ধার করা attendance UI/assets
- Android WebView wrapper ও JavaScript bridge
- Native Android daily reminder alarm + notification receiver
- Google Play Services Geofence receiver; app settings থেকে GPS monitoring চালু করলে office geofence নিবন্ধনের চেষ্টা করে
- Email report-এর জন্য ফোনের email app chooser
- GitHub Actions workflow: `Build Orbit APK`

## APK তৈরি করার সবচেয়ে সহজ পদ্ধতি: GitHub Actions
1. GitHub-এ নতুন repository বানান, নাম `Orbit` দিন.
2. এই ZIP-টি extract করুন; **ZIP ফাইলের ভেতরের ফাইল/ফোল্ডার** repository-তে upload করুন (ZIP-কে ZIP হিসেবেই repository-তে রাখলে build হবে না).
3. `Commit changes` করুন.
4. Repository → **Actions** → **Build Orbit APK** → **Run workflow** চাপুন.
5. Build শেষ হলে workflow run খুলে নিচে **Artifacts** থেকে `Orbit-debug-apk` ডাউনলোড করুন.
6. ZIP artifact extract করে `app-debug.apk` ফোনে কপি করুন এবং install করুন. Android চাইলে “Install unknown apps” অনুমতি দিন.

## Android Studio দিয়ে
1. Android Studio-তে এই folder খুলুন.
2. Gradle sync সম্পন্ন হতে দিন; JDK 17/Android SDK 35 লাগবে.
3. Build → Build Bundle(s) / APK(s) → Build APK(s).
4. APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ থাকবে.

## ইনস্টলের পর পরীক্ষা
- Orbit খুলে Profile সেট করুন.
- Settings/Location থেকে office coordinate ও radius ঠিক করে GPS চালু করুন.
- Android Settings → Apps → Orbit → Permissions-এ Location permission দিন; background geofence-এর জন্য Android-এর নির্দেশনা অনুযায়ী “Allow all the time” লাগতে পারে. Android 13+ এ Notifications allow করুন.
- Settings → Battery-তে Orbit-কে restricted না রাখুন; কিছু ফোনে auto-start/background activity অনুমতি দিতে হয়.
- Reminder time Save করে test notification চালান.
- Email report-এ valid recipient address দিন; email app খুলে draft review করে **Send** চাপতে হবে. এই build email-কে user consent ছাড়া background-এ silent-send করে না; automatic email delivery-க்கு secure backend/API credentials configure করতে হবে.

## গুরুত্বপূর্ণ সীমাবদ্ধতা—বাস্তব পরীক্ষা জরুরি
- এটি source ZIP-এ পাওয়া UI ও assets থেকে বানানো নতুন wrapper project; এটি সম্পূর্ণ original Android source project নয়.
- Geofence event native receiver-এ app বন্ধ থাকলেও queue-তে রেকর্ড হয়; attendance UI/local record-এ queue sync হয় অ্যাপ আবার খোলা/foreground হলে. Android/OEM battery restrictions ও location permission-এর কারণে সব ফোনে একই আচরণ নিশ্চিত নয়. কর্মীদের ফোনে field-test ছাড়া production-ready ধরে নেবেন না.
- Email report currently opens the installed email app with a summary; PDF/XLSX attachment নিজে থেকে যুক্ত হয় না এবং Send চাপতে হয়. Silent/automatic sending requires a secured backend or provider API; password/API secret APK-তে রাখবেন না.
- APK build pipeline compile artifact তৈরি করার জন্য; এখানে Android SDK build চালিয়ে binary পরীক্ষা করা হয়নি. GitHub Actions run-এ compile error হলে log থেকে সংশোধন করতে হবে.
- Attendance records এই app-এর local storage-এ থাকে. পুরোনো app-এর data নতুন app-এ নিজে থেকে transfer হবে না; পুরোনো app থেকে backup export করে Orbit-এ Restore করুন.
