package com.orbit.attendance

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.GeofenceStatusCodes
import java.io.File
import java.io.FileOutputStream
import java.util.Calendar
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("orbit_native", Context.MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestBasicPermissions()
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.loadWithOverviewMode = true
        web.settings.useWideViewPort = true
        web.settings.textZoom = 100
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(OrbitBridge(this), "EasyPunchNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }
    private fun requestBasicPermissions() {
        val required = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) required.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = required.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 410)
    }
    inner class OrbitBridge(private val ctx: Context) {
        @JavascriptInterface fun scheduleDailyReminder(kind: String, time: String, enabled: Boolean): String = try {
            val key = "${kind}_time"; prefs.edit().putString(key, time).putBoolean("${kind}_enabled", enabled).apply()
            if (enabled) schedule(kind, time) else cancel(kind)
            "OK"
        } catch (e: Exception) { "ERROR:${e.message}" }
        @JavascriptInterface fun openEmail(to: String, subject: String, body: String): String = try {
            val i = Intent(Intent.ACTION_SENDTO).apply { data = Uri.parse("mailto:"); putExtra(Intent.EXTRA_EMAIL, arrayOf(to)); putExtra(Intent.EXTRA_SUBJECT, subject); putExtra(Intent.EXTRA_TEXT, body); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            ctx.startActivity(Intent.createChooser(i, "Send Orbit attendance report").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "OK"
        } catch (e: Exception) { "ERROR:No email app available. ${e.message}" }
        @JavascriptInterface fun registerOfficeGeofence(lat: Double, lon: Double, radius: Float): String {
          return try {
            prefs.edit().putFloat("office_lat", lat.toFloat()).putFloat("office_lon", lon.toFloat()).putFloat("office_radius", radius).putBoolean("geo_enabled", true).apply()
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return "ERROR:Location permission not granted"
            val fence = Geofence.Builder().setRequestId("orbit_office").setCircularRegion(lat, lon, radius.coerceIn(30f, 1000f)).setExpirationDuration(Geofence.NEVER_EXPIRE).setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER or Geofence.GEOFENCE_TRANSITION_EXIT).setNotificationResponsiveness(15000).build()
            val request = GeofencingRequest.Builder().setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER or GeofencingRequest.INITIAL_TRIGGER_EXIT).addGeofence(fence).build()
            val intent = Intent(ctx, GeofenceReceiver::class.java)
            val pi = PendingIntent.getBroadcast(ctx, 710, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
            LocationServices.getGeofencingClient(this@MainActivity).addGeofences(request, pi).addOnSuccessListener { }.addOnFailureListener { prefs.edit().putString("geo_error", it.message).apply() }
            "OK"
          } catch (e: Exception) { "ERROR:${e.message}" }
        }
        @JavascriptInterface fun consumePendingPunches(): String = prefs.getString("pending_punches", "[]") ?: "[]"
        @JavascriptInterface fun acknowledgePendingPunches() { prefs.edit().putString("pending_punches", "[]").apply() }
        @JavascriptInterface fun saveDownload(base64: String, name: String, mime: String): String = try {
            val dir = File(ctx.getExternalFilesDir(null), "OrbitDownloads"); dir.mkdirs(); val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            FileOutputStream(File(dir, safe)).use { it.write(Base64.decode(base64, Base64.DEFAULT)) }; "OK"
        } catch (e: Exception) { "ERROR:${e.message}" }
    }
    private fun schedule(kind: String, time: String) {
        val parts = time.split(":"); if (parts.size != 2) return
        val hour = parts[0].toIntOrNull() ?: return; val minute = parts[1].toIntOrNull() ?: return
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("kind", kind)
        val pi = PendingIntent.getBroadcast(this, if (kind == "in") 801 else 802, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi) else am.set(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
    }
    private fun cancel(kind: String) { val pi = PendingIntent.getBroadcast(this, if (kind == "in") 801 else 802, Intent(this, ReminderReceiver::class.java).putExtra("kind", kind), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE); if (pi != null) (getSystemService(ALARM_SERVICE) as AlarmManager).cancel(pi) }
    override fun onResume() { super.onResume(); if (::web.isInitialized) web.evaluateJavascript("try{syncNativeGeofenceEvents&&syncNativeGeofenceEvents()}catch(e){}", null) }
    override fun onBackPressed() { if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
}
