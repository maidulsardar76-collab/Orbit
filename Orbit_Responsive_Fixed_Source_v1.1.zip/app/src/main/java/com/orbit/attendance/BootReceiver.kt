package com.orbit.attendance

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val p = context.getSharedPreferences("orbit_native", Context.MODE_PRIVATE)
        val app = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        // Re-schedule alarms without opening UI using the same receiver pending intents.
        for (kind in listOf("in", "out")) {
            if (!p.getBoolean("${kind}_enabled", false)) continue
            val time = p.getString("${kind}_time", if (kind == "in") "09:30" else "18:30") ?: continue
            val bits = time.split(":"); if (bits.size != 2) continue
            val cal = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY, bits[0].toIntOrNull() ?: 9); set(java.util.Calendar.MINUTE, bits[1].toIntOrNull() ?: 30); set(java.util.Calendar.SECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR, 1) }
            val pi = android.app.PendingIntent.getBroadcast(context, if (kind == "in") 801 else 802, Intent(context, ReminderReceiver::class.java).putExtra("kind", kind), android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
            val am = context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
            if (android.os.Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi) else am.set(android.app.AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        }
    }
}
