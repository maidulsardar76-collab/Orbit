package com.orbit.attendance

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent
import org.json.JSONArray
import org.json.JSONObject

class GeofenceReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val event = GeofencingEvent.fromIntent(intent) ?: return
        if (event.hasError()) return
        val kind = when (event.geofenceTransition) { Geofence.GEOFENCE_TRANSITION_ENTER -> "in"; Geofence.GEOFENCE_TRANSITION_EXIT -> "out"; else -> return }
        val prefs = context.getSharedPreferences("orbit_native", Context.MODE_PRIVATE)
        val arr = try { JSONArray(prefs.getString("pending_punches", "[]")) } catch (_: Exception) { JSONArray() }
        arr.put(JSONObject().put("kind", kind).put("timestamp", System.currentTimeMillis()))
        prefs.edit().putString("pending_punches", arr.toString()).apply()
    }
}
