package com.orbit.attendance

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val kind = intent.getStringExtra("kind") ?: "in"
        val prefs = context.getSharedPreferences("orbit_native", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("${kind}_enabled", false)) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("orbit_reminders", "Orbit reminders", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(context, 900, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val label = if (kind == "in") "IN" else "OUT"
        manager.notify(if (kind == "in") 801 else 802, NotificationCompat.Builder(context, "orbit_reminders").setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Orbit $label reminder").setContentText("Please check your attendance.").setAutoCancel(true).setContentIntent(open).build())
        val time = prefs.getString("${kind}_time", "09:30") ?: "09:30"
        val p = time.split(":"); if (p.size == 2) {
            val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, p[0].toIntOrNull() ?: 9); set(Calendar.MINUTE, p[1].toIntOrNull() ?: 30); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.DAY_OF_YEAR, 1) }
            val pi = PendingIntent.getBroadcast(context, if (kind == "in") 801 else 802, Intent(context, ReminderReceiver::class.java).putExtra("kind", kind), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi) else am.set(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
        }
    }
}
