# Orbit Android App — Responsive Fix v1.1

এই ZIP-টি Android Studio / GitHub Actions দিয়ে Debug APK build করার সোর্স প্রজেক্ট।

## এই আপডেটে
- মোবাইল স্ক্রিনে responsive spacing, button grid ও bottom navigation ঠিক করার CSS override যোগ করা হয়েছে।
- Android 10+ এ background location permission না থাকলে native geofence registration-কে সফল ধরে না নিয়ে স্পষ্ট error দেখানোর ব্যবস্থা করা হয়েছে।
- অ্যাপ প্রথমবার চালু হলে automatic IN/OUT-এর জন্য Android App Settings-এ গিয়ে Location → Allow all the time নির্বাচন করার নির্দেশ দেখায়।
- PDF/PNG/Excel/CSV/backup downloads Android-এর public Downloads/Orbit ফোল্ডারে সেভ হয়।
- বিদ্যমান attendance, salary, calendar, reminders, email summary, report export এবং backup/restore code রাখা হয়েছে।

## Build (GitHub Actions)
1. ZIP extract করে ভেতরের সব ফাইল repository root-এ রাখুন—`settings.gradle`, `build.gradle`, `app/`, `.github/` একই root-এ থাকবে।
2. Commit/push করুন অথবা Actions → Build Orbit APK → Run workflow দিন।
3. সফল build হলে `Orbit-debug-apk` artifact থেকে `app-debug.apk` নিন।

## গুরুত্বপূর্ণ সীমা
- এখানে Android SDK নেই, তাই এই পরিবেশে APK compile বা বাস্তব ফোনে পরীক্ষা করা সম্ভব হয়নি। GitHub Actions build success-ও বাস্তব GPS behaviour-এর নিশ্চয়তা নয়।
- Background geofence চালাতে Android Settings → Apps → Orbit → Permissions → Location → **Allow all the time** এবং Precise Location চালু করুন। Battery optimization/force-stop/device vendor-এর কারণে delivery দেরি হতে পারে।
- Geofence ইভেন্ট অ্যাপ বন্ধ থাকলে native queue-তে timestamp-সহ রাখা হয়; Orbit আবার খুললে attendance UI-তে sync হয়.
- Email feature email app-এ monthly summary draft খোলে. PDF/Excel file email-এ attach করতে হলে email app-এ আলাদা করে attach করতে হবে.
- Debug APK testing-এর জন্য; payroll/attendance-এর authoritative record হিসেবে ব্যবহারের আগে ফোনে IN, OUT, reboot, location permissions, downloads, reminders এবং exports আলাদাভাবে পরীক্ষা করুন।
