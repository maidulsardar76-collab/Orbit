# Orbit Android source — revised native bridge

এই প্যাকেজে সোর্স-কোড পর্যায়ে নিচের সংশোধন যোগ করা হয়েছে:
- WebView-এর geolocation permission callback যোগ করা হয়েছে।
- Android native print/PDF bridge যোগ করা হয়েছে।
- HTML-এর beginDownload/appendDownloadChunk/finishDownload/cancelDownload bridge যোগ করা হয়েছে, যা আগের JavaScript ডাউনলোড কোডের সঙ্গে মেলে।
- Geofence নিবন্ধনের asynchronous failure/registered অবস্থা SharedPreferences-এ রাখা হয়।

সীমাবদ্ধতা: এই ZIP ফোনে চালিয়ে পরীক্ষা করা হয়নি। GPS/geofence delivery, email chooser, PDF output এবং alarm notifications বাস্তব Android ডিভাইসে আলাদাভাবে যাচাই করতে হবে। ইমেল bridge ইমেল অ্যাপের draft/chooser খোলে; স্বয়ংক্রিয়ভাবে পাঠায় না।
